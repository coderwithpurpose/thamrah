import numpy as np
import cv2
import apriltag
import configs
from matplotlib import pyplot as plt

cap = cv2.VideoCapture(1)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

window = 'Camera'
cv2.namedWindow(window)
detector = apriltag.Detector()
# april tag length and width in meter
tag_size = 0.1524

# calibration and distortion coeficints that are unique to our camera
cal_mat = np.array([[727.3592, 0, 301.0924],[0, 726.8428, 221.0490],[0,0,1]])
dist_coef = np.array([-0.0098, -0.1054,0,0])

# arrays will be used to keep track with the change of x,z locations of the camera
x_locations = []
z_locations = []

# number of tags used
num_tags = 3

# declaring array that will hold pose of camera relative to origin
# where it will hold values for as many tags there are
Ho_c = np.zeros((num_tags+1,4,4))

# to keep track with all the tags detected in a single frame
# where each frame there is a max of id's that is == num_tags
num_ids = np.zeros(num_tags)

# the pose @ any location
def getRelativeTransform(tag_size, cal_mat, corners):
    s = tag_size/2.0 # in meter

    # actual 3-d corners of the tag
    object_points = np.array([[-s,-s,0],[s,-s,0],[s,s,0],[-s,s,0]])

    #obtain the transition, and rotation vectors
    ret, rvec, tvec = cv2.solvePnP(object_points, corners,
                                   cal_mat, dist_coef)

    R , J = cv2.Rodrigues(rvec) # converting rotation vector into 3x3 matrix

    # constructing the 4x4 pose matrix
    H = np.c_[R,tvec]
    H = np.vstack([H,[0,0,0,1]])
    H_inverse = H_inv(R,tvec)

    return H, H_inverse


# inverse of any pose matrix
def H_inv(R,t): #input is 3x3 rotation matrix and 3x1 transition vector

    # transpose of R
    RT = [[R[j][i] for j in range(len(R))] for i in range(len(R[0]))]
    holder = np.matmul(RT,t)
    HT = np.c_[RT, -holder]
    HI = np.vstack([HT, [0, 0, 0, 1]])
    return HI


# pose of camera relative to origin:
def cam_to_origin_pose (H_inv , H_origin):
    return np.matmul(H_origin,H_inv)

# reading the location when inputting the pose
def get_location(HO_C):
    x=HO_C[0][3]
    y=HO_C[1][3]
    z=HO_C[2][3]
    return x,y,z

# reading the rotation when inputting the pose
def get_rotation(HO_C):
    # we are only intrested in x, and z as y represent going up and down
    # where in reality the camera will be mounted and change in 2-d
    Rx = HO_C[0][2]
    Rz = HO_C[2][2]
    return Rx, Rz


f, axes = plt.subplots(1,1)
line_theta, = axes.plot([], [], 'b-', label = "path")
axes.set_ylim([0,-12])
axes.set_xlim([0,4])

# the closest tag
def get_closest_tag(Hc_t):
    prev = 100
    for i in range (0, len(Hc_t)):
        new_val = Hc_t[i]
        val = new_val [0][3]* new_val[2][3]
        if val < prev :
            prev = val
            idx = i

    return idx

# plt.ion()
f, axes = plt.subplots()
pos, = axes.plot([], [], 'r.')
dir, = axes.plot([], [], 'b-')

axes.set_xlim(0,4)
axes.set_ylim(-6.0)

plt.draw()

while True:
    success, frame = cap.read()
    if not success:
        # when done, plot all the different recorded locations that the camera saw with time

        plt.subplot(2,1,1)
        plt.plot(x_locations)
        plt.ylim(0,4)
        plt.ylabel('x_location')
        plt.subplot(2,1,2)
        plt.plot(z_locations)
        plt.ylim(-5,-6.5)
        plt.ylabel('z_locations')
        plt.show()
        break

    # convert input frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    detections, dimg = detector.detect(gray, return_image=True)

    num_detections = len(detections)
    # printing how many tags it detected
    print 'Detected {} tags.\n'.format(num_detections)
    # resetting for next frame
    tag_id = 0
    Ho_c = np.zeros((num_tags+1,4,4))
    num_ids = np.zeros(num_tags+1)
    Ht_c = np.zeros((num_tags+1,4,4))

    H_closest = np.zeros((4,4))
    H_closest_inv = np.zeros((4,4))
    closest_idx = 0

    # going through all the tags detected in a single frame
    for i, detection in enumerate(detections):
        print 'Detection {} of {}:'.format(i+1, num_detections)
        print
        print detection.tostring(indent=2)
        print

        tag_id = detection[1]

        #pose of tags relative to the camera and its inverse
        H_inst, H_inst_inv = (getRelativeTransform(tag_size, cal_mat, detection[7]))
        # saving all the h tag relative to camera
        Ht_c[tag_id] = H_inst


        #pose of the tags to the origin
        H_origin = configs.tags[tag_id]

        #pose of camera to the origin
        Ho_c[tag_id] = cam_to_origin_pose(H_inst_inv, H_origin)
        # counts of tag detected
        num_ids[tag_id]+=1

    # method 2, using closest tag
    # closest_idx = get_closest_tag(Ht_c)
    # H_closest = Ht_c[closest_idx]
    # next find its inverse + multiply with Ho_t




    #which tag was detected
    new_idxs = [i for i,e in enumerate (num_ids) if e!=0]

    # getting all non zero indices
    # inits of all cam to origin locations
    X = np.zeros(len(new_idxs))
    Y = np.zeros(len(new_idxs))
    Z = np.zeros(len(new_idxs))
    Rx = np.zeros(len(new_idxs))
    Rz = np.zeros(len(new_idxs))

    # another idea is to actually use the one with closes position to the tag

    # to only run when tags where detected
    if len(new_idxs) > 0 :
        # getting locations
        for idx in range(0,len(new_idxs)):
            # so it doesn't keep saving plots


            #location and rotation based on each tag
            x,y,z = get_location(Ho_c[new_idxs[idx]])
            rx,rz = get_rotation(Ho_c[new_idxs[idx]])

            #location and rotation based on all tags
            X[idx] = x
            Y[idx] = y
            Z[idx] = z
            Rx[idx] = rx
            Rz[idx] = rz

        # averiging location from calculated location from diferent tags
        Cam_x = np.mean(X)
        Cam_y = np.mean(Y)
        Cam_z = np.mean(Z)
        Cam_rx = np.mean(Rx)
        Cam_rz = np.mean(Rz)

        print(Cam_x,'X')
        print(Cam_y,'Y')
        print(Cam_z,'Z') # tested x, and z values are correct with +-10cm error, with range of 2m
        print(Cam_rx,'rotation of camera on X')
        print(Cam_rz,'rotation of camera on Z')

        # collect all continouse loaction readings and draw them
        # x_locations.append(Cam_x)
        # z_locations.append(Cam_z)

        # plotting in 2-d the instantinuos camera location
        pos.set_data(Cam_x,Cam_z)
        # dir.set_data([Cam_x,Cam_x+Cam_rx/5.0],[Cam_z,Cam_z + Cam_rz/5.0])
        # plt.scatter(Cam_x,Cam_z,s=20)
        # plt.plot([Cam_x,Cam_x+Cam_rx/5.0],[Cam_z,Cam_z + Cam_rz/5.0])
        # plt.xlim(0,4)
        # plt.ylim(-6,0)
        #
        plt.draw()
        plt.pause(0.2)

    overlay = frame / 2 + dimg[:, :, None] / 2 ;

    cv2.imshow(window, overlay)
    k = cv2.waitKey(1)

    if k == 27:
        break

plt.ioff()
plt.show()