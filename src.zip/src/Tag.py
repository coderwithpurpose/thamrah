
class tag_pose:
    # Rocket simulates a rocket ship for a game,
    #  or a physics simulation.
    def __init__(self, tag_id, tag_pose):

        self.t = tag_id
        self.h = tag_pose



