import Tag
import numpy as np

tag0 = np.zeros((4,4))
tag1 = Tag.tag_pose("00001", np.array([[1,0,0,1.645],[0,1,0,0],[0,0,1,0],[0,0,0,1]]))
tag2 = Tag.tag_pose("00002", np.array([[0,0,-1,0],[0,1,0,0],[1,0,0,-1.318],[0,0,0,1]]))
tag3 = Tag.tag_pose("00003", np.array([[1,0,0,3.3],[0,1,0,0],[0,0,1,0],[0,0,0,1]]))
tags = (tag0,tag1.h,tag2.h,tag3.h)


